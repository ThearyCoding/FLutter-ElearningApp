package com.example.e_leaningapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
